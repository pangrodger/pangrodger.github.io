<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'gPxQGG0X19FzaPlWWWjzcwdjA');
    define('CONSUMER_SECRET', 'nuM6iS3SHHzhGdO6O1uwq8Cgbq0G2ZBePmI5NLupUZx8pE4gk9');

    // User Access Token
    define('ACCESS_TOKEN', '62739365-vRagIYPlSlmdZYAgRdn3ifEuBK482KYO0tRB8qEXF');
    define('ACCESS_SECRET', 'zkxfxAQBG2L7R05CZ0M32oUyUzTekcwR0anhlaqsB3fsH');